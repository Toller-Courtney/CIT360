package fortuneCookie;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
/*this is telling the servlet were to go to get our web page to display for the user*/
@WebServlet(name = "YourFortune", urlPatterns = {"/YourFortune"})

public class YourFortune extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        PrintWriter output = response.getWriter();
        response.setContentType("text/html");

        /*This block of code is getting the parameters from out fortune.html file
        * to use an display on our web page*/
        String userName = request.getParameter("name");
        int userNumber = Integer.parseInt(request.getParameter("number"));
       /*This block of code is everything needed for our switch statement to
       * display all the fortunes for each of the numbers that the user can enter
       * this also contains a default message in case the user enters a number
       * outside of our range.*/
        int fortune = userNumber;
        String fortuneString;
        switch (fortune) {
            case 1:
                fortuneString = "Never hesitate to tackle a difficult problem.";
                break;
            case 2:
                fortuneString = "You will soon gains something you have always wanted.";
                break;
            case 3:
                fortuneString = "Your smile is a treasure to all who know you.";
                break;
            case 4:
                fortuneString = "Be Prepared for big and small things to fall in your path.";
                break;
            case 5:
                fortuneString = "All your hard work will soon pay off.";
                break;
            case 6:
                fortuneString = "Beauty surrounds you because you create it.";
                break;
            case 7:
                fortuneString = "Take advantage of your great imagination.";
                break;
            case 8:
                fortuneString = "Long life is in store for you.";
                break;
            case 9:
                fortuneString = "Your creativity will take you unexpected places.";
                break;
            case 10:
                fortuneString = "Good news of a long awaited event will soon arrive.";
                break;
            default:
                fortuneString= "We are all out of fortunes, please come back tomorrow";
        }
        /*this block of code is going to display the results out the information
        * that our sure enters in to to our program.*/
        output.println("<html><head><title>Your Digital Fortune Cookie</title></head><body>");
        output.println("<h1> " + userName +","+ "Your Fortune Cookie Says:" + fortuneString);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter output = response.getWriter();
        output.println("The Resource you are requesting is not available directly.");
    }
}
