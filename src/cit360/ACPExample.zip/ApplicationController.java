package cit360;

import java.util.HashMap;
/*This is our application controller. It is basically handles all the
 * computing and handling of the different situations the application 
 * presents to it. The Application delegates everything here and then
 * the Application controller sents it offto the right places
 * to be processed.*/

public class ApplicationController {

	/*Here we are creating our new HashMap to be used through our application.
	 * This is going to allow us to find the commands the user has selected
	 * within the map. This completely eliminates the need for if statements
	 * and switch statements. It is much easier to read, handle, and debug 
	 * if something goes wrong. */
	public static HashMap<String, Handler> handlerMap= new HashMap<String, Handler>();
	
	/*In this method we are passing in the command that the user has indicated and
	 * the two numbers the enter. The command is then picked up by the handlerMap 
	 * and sent to the proper class to be calculated.*/
	public void handlerRequest(String command, Double number1, Double number2) {
		handlerMap.put("-", new Subtract());
		handlerMap.put("+", new Add());
		handlerMap.put("*", new Multiply());
		handlerMap.put("/", new Divide());

	
		/*This is saying handler, look in the hashMap and get 
		 * the value that is associated with the command. It
		 * will return the new instance of whatever command
		 * the user entered */
		Handler handler= handlerMap.get(command);
		
		/*Here we are saying that whatever handler (command) is indicated
		 * from the hashmap, calculate what is in there and pass in number 1 and 
		 * number 2 into calculate in the handler class.
		 * */
		handler.calculate(number1, number2);
	}
}
