package cit360;
/*In this class an the other operation classes (/-*) 
 * all implement the handler class and they have to
 * implement the calculate method with the parameter
 * that have been passed in from the user.*/
public class Add implements Handler {
	public void calculate(Double number1, Double number2) {

		/*Here we are telling our class what needs to be done 
		 * when what calculate is called from the application controller */
		Double result= number1 + number2;
		System.out.print(result);
		}
}
