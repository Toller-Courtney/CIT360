package cit360;

/*This is our handler interface. In order for the calculate
 * method to be implements across all of our command classes
 * (/*-+) they have to IMPLEMENT handler. We are used to using
 * the extends key word but when you are multiple interfaces
 * running, they need to implement because "extends" only 
 * allows for 1 thing to run at a time.*/
public interface Handler {

	/*the numbers that the user enters are passed into this method
	 *  and the sent to */
	void calculate(Double number1, Double number2);
}
