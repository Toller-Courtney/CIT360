package cit360;

import java.util.Scanner;

/*This class represents our simple application, a calculator. 
 * This is where all of the code is that the user will see 
 * interact with. It then takes all that information and
 * delegates it to the application controller to deal with.*/
public class Application {

	public static void main(String[] args) {
		/*Here we are creating a new instance of the Application 
		 * controller and that delegates the commands to our handle
		 * command in the application controller
		 *  */
		ApplicationController delegate =new ApplicationController();
	
		/*Here we are creating a new scanner to be able to
		 * capture the users input and use it in our application*/
		Scanner userInput=new Scanner(System.in);	
		System.out.println("Welcome to the Math Made Easy Calculator!");
		/*In this block of code we are going to print out what we
		 * want the user to see and enter into our application. 
		 * They will enter 2 numbers and a mathematical operation
		 * to be handled and calculated by our program and then 
		 * the results will be displayed to them.*/
		System.out.printf("Please enter your first number:");
		
		/*We need to parse the double to a string because the
		 * program is interpreting the input from the user as
		 * a string and not a double.  However, the application
		 * needs it to be in double from in order to do the
		 * mathematical calculations on it.  */
		Double number1=Double.parseDouble(userInput.nextLine());
		
		System.out.println("Please enter a mathematical operator(+,-,*,/):");
		/*This is the command that we will be using and passing into our
		 * application controller to be matched with the appropriate
		 * command in our HashMap. */
		String command= userInput.nextLine();
		/*prompting the user for their second number*/
		System.out.println("Please enter your second Number:");
		Double number2= Double.parseDouble(userInput.nextLine());
		
		/*Here we are going t o display the results of the
		 * users input*/
		System.out.println(number1 + " " + command + " "+ number2 + " " + "=");
		/*here we are calling the instance of the Application controller
		 * we created above and then it passes the command and two numbers 
		 * to our handlerRequest in the ApplicationController to be
		 * processed*/
		delegate.handlerRequest(command, number1, number2);
		/*This is closing the scanner and getting rid of the
		 * warning that pops up if you haven't closed your 
		 * scanner*/
		userInput.close();
		}
}
