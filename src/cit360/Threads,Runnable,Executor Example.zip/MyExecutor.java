package cit360;


import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


/*In this example I am going to demonstrate
 * how Threads, Runnable, and Executors works.
 *  This example is a very simplified 
 *  look at my day, I will be doing my homework
 *   and then check Zillow when a notification pops up. 
 *   A girl's gotta eat so I included snack breaks
 *   to curb the hanger. I will also include a 
 *   bed time count down because aren't we all
 *   counting down until bed time during a long
 *   stressful day?  */

public class MyExecutor {

	public static void main(String[] args) {

		/*
		 * Here we are going to call for a thread outside the main method
		 */
		addThreads();

	}
/*Here we are creating our addThreads method that will hold all of 
 * code needed to execute our threads.*/
	public static void addThreads() {

		/*
		 * This is creating our thread pool. It is a fixed thread pool
		 * which means that only the number of threads indicated 
		 *  can be run at a time. If there are more than that number
		 *  in our case, 5 the first 5 threads will execute and the
		 *  rest will sit in a queue until the others have finished
		 *  and they then they will run.
		 */
		
		ExecutorService events = Executors.newFixedThreadPool(5);
		
		/*
		 * This block or code is where we tell the program that we want to 
		 * start executing our threads.we are going to execute all the 
		 * thread in our thread pool. we call our events executor 
		 * and within that we create a new object for each of our classes 
		 * that we want to run. 
		 */
				events.execute(new DoHomeworkExecutor());
				events.execute(new CheckZillowExecutor(" DING Yay! A New house was added!"));
				events.execute(new ObtainSustenanceExecutor(" Time for a Snack..."));
				events.execute(new BedTimeExecutor());
				
		/*Here we are telling the program to shut down after each of the 
		 * thread have finished running.*/		
		events.shutdown();	
	}
	
}