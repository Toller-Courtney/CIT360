package cit360;

import java.util.concurrent.TimeUnit;

/*This class is very similar to my ObtainSustenance class
 * We just made a few adjustments to that it will
 * print out what we want it to when this thread 
 * is ran. It implements Runnable which means that
 * we have to freedom to use as many interface as 
 * we want without running into problems.*/
public class CheckZillowExecutor implements Runnable {

	/*Here we are declaring the variable that we
	 * will be using in our thread*/
	
	private String checkingZillow;
	
	
	 /*This is our constructor that is saying
	  * the new checkZillow is going to be what is 
	  * passed in to the constructor.*/
	public CheckZillowExecutor(String checkingZillow) {
		this.checkingZillow= checkingZillow;
}
	/*Here is our run method, this is required for
	 * being able to run our thread. without it,
	 * this thread would not function.*/
	public void run() {
		
		/*Here we are creating a for loop to increment 
		 * through our thread 7 times and display what 
		 * we have indicated with the System.out.*/
		for(int i=1; i<=7; i++) {
		/*Here is the message we are going to 
		 * display when the method is locked*/
		System.out.println("I have to find my Dream House..." +this.checkingZillow);
		
		/*This try block is saying that every 3000 milliseconds
		 *  we want this thread to run. Our catch is there to
		 *  alert us if there is any interruptions in the 
		 *  running of our thread*/
		try {
			TimeUnit.MILLISECONDS.sleep(3000);
		}catch (InterruptedException e) {
			System.out.println(e);
		}
		}
		
	}
}
