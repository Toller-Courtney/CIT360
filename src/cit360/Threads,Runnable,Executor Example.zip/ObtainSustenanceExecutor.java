package cit360;

import java.util.concurrent.TimeUnit;
/*This class is very similar to my CheckZillowExecutor class
 * We just made a few adjustments to that it will
 * print out what we want it to when this thread 
 * is ran. It implements Runnable which means that
 * we have to freedom to use as many interface as 
 * we want without running into problems*/
public class ObtainSustenanceExecutor implements Runnable{
	/*Here we are declaring the variable that we
	 * will be using in our thread*/
	private String timeToEat;
	
	 /*This is our constructor that is saying
	  * the new timeToEat is going to be what is 
	  * passed in to the constructor.*/
	public ObtainSustenanceExecutor(String timeToEat) {
		this.timeToEat= timeToEat;
	}
	/*This is our run method that is required for
	 * our thread to run. without it... Failure!*/
	public void run() {

		/*Here is our loop that increments through
		 * 5 times and then displays what we have 
		 * indicated below, ever time is runs.*/
		for(int i=1; i<=5;i++) {
			
		System.out.println("Back off man, I'm starving!" +this.timeToEat);
		/*This try block is similiar to the other classes
		 * is is indicating that every 4000 milliseconds
		 * our thread will run.*/
		try {
			TimeUnit.MILLISECONDS.sleep(4000);
		}catch (InterruptedException e) {
			System.out.println(e);
		}
		}
	
	}
	}

