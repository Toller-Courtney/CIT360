package cit360;

import java.util.concurrent.atomic.AtomicInteger;
/*In this class I am demonstrating how the Atomic
 * Integer works with Executors. WE are implementing
 * runnable here so that we can use as many
 * interfaces as we need to. for this example
 * we will only need one.*/
public class BedTimeExecutor implements Runnable{
	/*Here we are creating our new AtomicInteger object
	 * to use on our loop  that will count down until 
	 * bed time*/
private AtomicInteger count= new AtomicInteger();
/*As always, we have to creat our run() method or
 * we can not run our threads.*/
public void run() {
	/*Here we are creating our for loop that will
	 * decrement from 10 to 1 in our threads example.
	 * this is representiong how many hours there
	 * are until bedtim.*/
	for(int i=10;i>0;i--){
		/*Here we are calling our bedTimeCountDown
		 * method and passing in i */
		bedTimeCountDown(i);
		/*Here we are calling our AtomicInteger and
		 * using the incremetAndGet()method to 
		 * increment the value each time and 
		 * update the old value.*/
		count.incrementAndGet();
		/*Here is what we are going to display each
		 * time this thread is ran.*/
		System.out.println(i+ " Hour(s) until bed time.");
	}
}
/*This method is getting the count and then
 * returning that count */
public int getCount() {
	return this.count.get();
}

/*Here are are creating our bedTimeCountDown method 
 * that takes the i parameter from our loop above and
 * withing our try catch statement we are telling the 
 * method how lont we want it to run for. on this case 
 * we want it to run every 3 seconds and display to the
 * console what we have indicated in our run method.*/
private void bedTimeCountDown(int i) {
	try {
		Thread.sleep(i*300);
	}catch(InterruptedException e) {
		System.out.println(e);
	}
}
}
