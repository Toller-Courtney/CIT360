package cit360;

public class DoHomeworkExecutor extends Thread{
	/*This run method is required for thread to
	 * execute the code and run it concurrently 
	 * with other threads. Without this, our 
	 * threads wont run.*/
	public void run() {
		/*Here are are declaring our string that we will
		 * be using to print out the message we want 
		 * to the console*/

		String doingHomework;
		
		/*Here we are creating a for loop to have our
		 * thread execute ad have our string display 
		 * 20 times to the console. */
		for(int i=1; i<=20; i++) {
			doingHomework= "Diligently working on homework";
			
			System.out.println(doingHomework);
			
			/*This is our try statement that is required for
			 * our sleep method. This is telling our code to
			 * sleep for 2 seconds */
			try {
				Thread.sleep(1000);
				/*This is going to catch the exception
				 * when our thread id interupted. This
				 * exception is thrown whenever 
				 * .sleep() runs*/
			}catch(InterruptedException e) {
				System.out.println(e);
			}
		}
	}
}
